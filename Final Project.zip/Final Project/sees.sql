
CREATE TABLE PRODUCT (
    Dietary_Info    Char(20)        NOT NULL,
    weight          Number(20)      NOT NULL,
    Product_Style   Char(50)        NOT NULL,
    Product_Number  Varchar(6)      NOT NULL,
    Product_Name    Char(80)       NOT NULL,
    Product_Price   Varchar(20)     NOT NULL,
    Product_Gift_Wrap       Char(30)     NULL,
    Product_Description    Varchar(1000)    NULL,
    Product_Stars           Number(5)       NOT NULL,
    Product_In_Stock        Char(7)    NOT NULL,
    CONSTRAINT ProductPK PRIMARY KEY(Product_Number),
    CONSTRAINT ProductAK1 UNIQUE(Product_Name, Product_Price, Product_In_Stock)
    );
    
    ALTER TABLE PRODUCT
    ADD CustomMix    Char(1)    NULL;
    
    ALTER TABLE PRODUCT
    MODIFY (CustomMix DEFAULT 'Y')
    ADD CONSTRAINT checkCustom_y_n CHECK (CustomMix IN ('Y', 'N'));
    
    INSERT INTO PRODUCT (Dietary_Info, Weight, Product_Style, Product_Number, Product_Name, Product_Price, Product_Gift_Wrap, 
    Product_Description, Product_Stars, Product_In_Stock, CustomMix)
VALUES ('None','1','Box','9011','Dark Chocolate Nuts and Chews','$27.50','N',
'This traditional dark chocolate assortment is packed with top-quality peanuts California-grown English walnuts almonds chewy Caramel honey Scotchmallow� and more-all coated with delicious aged dark chocolate',
'5','Y','N');

SELECT * 
FROM product;

INSERT INTO PRODUCT (Dietary_Info, Weight, Product_Style, Product_Number, Product_Name, Product_Price, Product_Gift_Wrap, 
    Product_Description, Product_Stars, Product_In_Stock, CustomMix)
VALUES ('None','1','Box','9106','Milk California Brittle','$27.50','Y',
'This is a special Sees confection you wont find anywhere else. Its an inspired marriage of two delightful flavors: toffee brittle and a coating of smooth milk chocolate. Once you try one youll be glad you have an entire box!',
'5','Y','N');

INSERT INTO PRODUCT (Dietary_Info, Weight, Product_Style, Product_Number, Product_Name, Product_Price, Product_Gift_Wrap, 
    Product_Description, Product_Stars, Product_In_Stock)
VALUES ('None','1','Box','789','Milk Pecan Buds and Marzipam','$27.50','Y',
'25% of milk pecan buds and 75% of marzipam','0','Y');

    
    CREATE TABLE PRODUCT_ORDER (
        Order_Quantity       Number(5)       NOT NULL,
        Shipping            Varchar(50)     NOT NULL,
        Product_Number  Varchar(6)      NOT NULL,
        Order_Ship_Type     Char(50)        NOT NULL,
        Order_Ship_Date     Number(6)       NOT NULL,
        Order_Date_Delivered Number(6)      NOT NULL,
        Order_Gift_Msg      Varchar(1000)   NULL,
        Min_Order    Char(20)   NULL,
        CONSTRAINT QuantityPK PRIMARY KEY(Order_Quantity),
        CONSTRAINT QuantityAK1 UNIQUE (Order_Quantity, Shipping, Order_Ship_Date),
        CONSTRAINT  productnumberFK  FOREIGN KEY (product_number)
        REFERENCES PRODUCT (Product_Number)
        );
        
        SELECT *
        FROM product_order;
      
    DROP TABLE CUSTOMMIX; 
    CREATE TABLE CUSTOMMIX (
        CustomMixID     Char(20)        NOT NULL,
        Cm_Pn_Quantity          Number(20)   NOT NULL,
        Product_Number  Varchar(6)      NOT NULL,
        CustPercent  Char(3)   NOT NULL,
        CustLabel   Char(50)  NOT NULL,
        GiftWrapped  Char(1) NOT NULL,
        Box   Char(10)   NOT NULL,
        CONSTRAINT CustomMixPK   PRIMARY KEY(CustomMixID),
        CONSTRAINT CustomMixAK1  UNIQUE(CustPercent, CustLabel),
        CONSTRAINT ProductFK FOREIGN KEY(Product_Number)
        REFERENCES PRODUCT(Product_Number)
        );
        
        
        SELECT *
        FROM custommix;
        
      INSERT INTO CUSTOMMIX (CustomMixID, Cm_Pn_Quantity, Product_Number, CustPercent, CustLabel, GiftWrapped, Box)
    VALUES ('10', '1', '9106', '25%', 'Milk Pecan Buds', 'Y', 'Y');
    
    INSERT INTO CUSTOMMIX (CustomMixID, Cm_Pn_Quantity, Product_Number, CustPercent, CustLabel, GiftWrapped, Box)
    VALUES ('20', '1', '9011', '75%', 'Marzipan', 'Y', 'Y');
    
        
    CREATE TABLE CUSTOMER (
        CustID      Number(10)      NOT NULL,
        CustLast    Char(50)        NOT NULL,
        CustFirst   Char(50)        NOT NULL,
        Org_Name    Char(40)        NOT NULL,
        Street_Address  Char(50)   NOT NULL,
        City         Char(50)       NOT NULL,
        State       Char(2)         NOT NULL,
        Logical     Char(2)         NULL,
        Zip         Char(9)         NOT NULL,
        Phone       Char(50)        NOT NULL,
        Phone_Ext   Char(3)         NULL,
        Shipping    Varchar(50)     NOT NULL,
        Cust_Email  Char(100)    NOT NULL,
        CONSTRAINT CustPK PRIMARY KEY(CustID),
        CONSTRAINT CustAK1 UNIQUE(Cust_Email, Logical)
        );
        
        INSERT INTO CUSTOMER (CustID, CustLast, CustFirst, Org_Name, Street_Address, City, State, Logical, Zip, Phone, Phone_Ext, 
        Shipping, Cust_Email)
VALUES ('98958', 'Hvatum', 'Margaret', 'Information Systems Department', '11333 Big Bend', 'Kirkwood', 'MO', '0', '63124', '314-984-7518',
'0', 'Free shipping', 'mhvatum@stlcc.edu');

SELECT * 
FROM Customer;

DROP TABLE credit_card;
        
    CREATE TABLE CREDIT_CARD (
        Payment_Type    Char(20)    NOT NULL,
        Credit_Card     Char(20)    NOT NULL,
        Gift_Card       Char(50)    NULL,
        Cc_Number       Number(20)  NOT NULL,
        CustID      Number(10)      NOT NULL,
        Expiration      Char(6)     NOT NULL,
        Security_Code   Char(30)   NOT NULL,
        Address_Match   Char(100)   NOT NULL,
        CONSTRAINT PaymentPK PRIMARY KEY(Payment_Type),
        CONSTRAINT PaymentAK1 UNIQUE(Address_Match)
        );
        
        INSERT INTO CREDIT_CARD (CustID, Payment_Type, Credit_Card, Gift_Card, Cc_Number, Expiration, Security_Code, Address_Match)
VALUES ('98958','Credit Card','Visa','N','8834111122223333','5/15','321','Information Systems Department: 11333 Big Bend, Kirkwood, MO 63124');


SELECT *
FROM credit_card;
        
    CREATE TABLE PROMOTIONS (
        Promotion_ID      Char(5)        NOT NULL,
        StartDate           Number(6)   NOT NULL,
        EndDate             Number(6)   NOT NULL,
        Promo_Desc        Varchar(1000)  NULL,
        Discount          Char(4)        NULL,
        Freeship_Min      Char(6)        NULL,
        Free_Shipping      Char(2)      NULL,
        CONSTRAINT PromoDate  CHECK (StartDate < EndDate),
        CONSTRAINT StartDate CHECK((StartDate >= 1000) AND (StartDate <= 2100)),
        CONSTRAINT EndDate CHECK((EndDate >= 1000) AND (EndDate <= 2100)),
        CONSTRAINT PromotionPK PRIMARY KEY(Promotion_ID),
        CONSTRAINT ShippingAK1     UNIQUE(Free_Shipping, Freeship_Min),
        CONSTRAINT Check_y_n CHECK (Free_Shipping IN ('Y', 'N'))
        );
        
        SELECT * 
        FROM promotions;
        
    CREATE TABLE ORDER_ITEM (
        Item_Desc       Varchar(1000)   NOT NULL,
        Order_Number    Char(5)    NOT NULL,
        Product_Number  Varchar(6)      NOT NULL,
        CustomMixID   Char(20)    NOT NULL,
        CONSTRAINT OrderPK   PRIMARY KEY(Order_Number),
        CONSTRAINT OrderAK1  UNIQUE(Item_Desc),
        CONSTRAINT ProductNumFK FOREIGN KEY(Product_Number)
        REFERENCES PRODUCT (Product_Number)
        );
        
        SELECT * 
        FROM order_item;
        
        
        